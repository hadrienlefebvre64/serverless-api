// 'use strict';
// const Ticket = require('./models/Ticket');

// module.exports.createTicket = async (event) => {
//   return {
//     statusCode: 200,
//     body: JSON.stringify(
//       {
//         message: 'Your ticket was created successfully!',
//         input: event,
//       },
//       null,
//       2
//     ),
//   };
//
//   // Use this code if you don't use the http event with the LAMBDA-PROXY integration
//   // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };
// };


'use strict';

const createTicket = require('./handlers/create');

const create = (event, context, callback) => {
    const data = JSON.parse(event.body);
    createTicket(data)
        .then(result => {
            const response = { body: JSON.stringify(result) };
            callback(null, response);
        })
        .catch(callback);
};


module.exports = {
    create,
};
