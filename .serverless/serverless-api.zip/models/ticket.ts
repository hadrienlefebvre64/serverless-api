export interface HubspotTicket {
    createdAt: Date,
    archived: boolean,
    id: number,
    properties: {
        createdate: Date,
        hs_lastmodifieddate: Date,
        hs_pipeline: string,
        hs_pipeline_stage: string,
        hs_ticket_priority: string,
        hubspot_owner_id: number,
        subject: number,
    },
    updatedAt: Date,
}
